"use client";
const topics=[
 {terms:["spina bifida"],title:"Spina Bifida & Pain",subtitle:"Disability · Pain assessment",summary:"Pain can involve several mechanisms and varies between people. The essay discusses evidence limits and the proposed counselor-training framework.",href:"/journal/steady-state-methadone-chronic-pain"},
 {terms:['methadone'],title:'Methadone',subtitle:'Opioid pharmacology · Chronic pain and recovery',summary:'Elimination, pain relief, and withdrawal suppression follow different time courses. Effects vary by person. Evidence for OUD treatment and neuropathic pain must be assessed separately.',href:'/journal/steady-state-methadone-chronic-pain'},
 {terms:['piracetam'],title:'Piracetam',subtitle:'Racetam · Narrative monograph',summary:'Research on membrane effects and cognition spans different populations and outcomes. Mechanistic findings do not establish benefit in healthy adults.',href:'/nootropics/racetams/piracetam'},
 {terms:['oxiracetam'],title:'Oxiracetam',subtitle:'Racetam · Narrative monograph',summary:'Review proposed mechanisms and clinical studies alongside their methodological limitations.',href:'/nootropics/racetams/oxiracetam'},
 {terms:['aniracetam'],title:'Aniracetam',subtitle:'Racetam · Narrative monograph',summary:'The review distinguishes AMPA-related mechanisms, animal findings, and human evidence.',href:'/nootropics/racetams/aniracetam'},
 {terms:['noopept'],title:'Noopept',subtitle:'Dipeptide analogue · Research review',summary:'Preclinical neurotrophic findings require careful separation from evidence of clinical benefit.',href:'/research/noopept'},
 {terms:['idebenone'],title:'Idebenone',subtitle:'Benzoquinone · Research review',summary:'Mitochondrial mechanisms and clinical outcomes require indication-specific interpretation.',href:'/research/idebenone'},
 {terms:['blood brain barrier','blood–brain barrier','bbb'],title:'The Blood–Brain Barrier',subtitle:'Transport · Brain exposure',summary:'Brain exposure depends on several processes, including transport and clearance. Peripheral pathways may also influence brain function.',href:'/journal/the-gatekeeper-blood-brain-barrier'},
];
export function InstantAnswer({query}:{query:string}){
 const q=query.trim().toLowerCase();const bang=/^!(scholar|pubmed|doi)\s+(.+)$/i.exec(query.trim());
 const topic=topics.find(t=>t.terms.some(term=>new RegExp("\\b"+term+"\\b", "i").test(q)));
 if(bang){const value=bang[2].trim();const url=bang[1].toLowerCase()==='pubmed'?'https://pubmed.ncbi.nlm.nih.gov/?term='+encodeURIComponent(value):bang[1].toLowerCase()==='doi'?'https://search.crossref.org/?q='+encodeURIComponent(value):'https://scholar.google.com/scholar?q='+encodeURIComponent(value);return <aside className="ddg-instant-card"><h3>Search {bang[1]==='doi'?'DOI records':bang[1]}</h3><a href={url} target="_blank" rel="noopener noreferrer">Search for “{value}” ↗</a><p>The external search opens only when you select this link.</p></aside>}
 if(!topic)return null;
 return <section id="ddgInstantAnswer" className="ddg-instant-card" aria-label="Research quick answer" aria-live="polite"><span className="ddg-tag">// QUICK ANSWER</span><h3>{topic.title}</h3><p className="ddg-meta">{topic.subtitle}</p><p>{topic.summary}</p><div className="ddg-footer"><a className="neu-btn" href={topic.href}>View full review →</a><span>Evidence varies by outcome</span></div><p className="ddg-meta">Tip: try !scholar, !pubmed, or !doi followed by search terms.</p></section>
}

export function bangTarget(query:string):string|null{
 const match=/^!(\w+)(?:\s+(.*))?$/.exec(query.trim());if(!match)return null;
 const command=match[1].toLowerCase(),term=(match[2]||"").trim();
 if(command==='tbr'||command==='thunderbird')return '/thunderbird-rising';if(command==='policy')return '/policy';
 if(!term)return null;
 if(command==='scholar')return 'https://scholar.google.com/scholar?q='+encodeURIComponent(term);
 if(command==='pubmed')return 'https://pubmed.ncbi.nlm.nih.gov/?term='+encodeURIComponent(term);
 if(command==='ddg')return 'https://duckduckgo.com/?q='+encodeURIComponent(term);
 if(command==='doi'){const doi=term.replace(/^https?:\/\/doi\.org\//i,'');return /^10\.\d{4,9}\/\S+$/.test(doi)?'https://doi.org/'+encodeURI(doi):null;}
 if(command==='mono')return topics.find(t=>t.terms.includes(term.toLowerCase()))?.href||null;
 return null;
}
