"use client";
import { useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
export function ReferenceUtilities(){
 const path=usePathname();const dialog=useRef<HTMLDialogElement>(null);const [status,setStatus]=useState("");
 useEffect(()=>{
  const timers=new Set<ReturnType<typeof setTimeout>>();
  const enhance=()=>{
   document.querySelectorAll<HTMLElement>('.apa-entry, .dir-item').forEach(entry=>{
    if(entry.querySelector('.cite-copy-btn'))return;
    const button=document.createElement('button');button.type='button';button.className='cite-copy-btn';button.textContent='Copy';button.setAttribute('aria-label','Copy reference citation');
    button.addEventListener('click',async()=>{
     const clone=entry.cloneNode(true) as HTMLElement;clone.querySelectorAll('button').forEach(b=>b.remove());
     const citation=entry.dataset.citation||clone.textContent?.trim()||'';
     let ok=false;
     try{await navigator.clipboard.writeText(citation);ok=true;}catch{
      const field=document.createElement('textarea');field.value=citation;field.style.cssText='position:fixed;left:-10000px';document.body.appendChild(field);field.select();try{ok=document.execCommand('copy');}catch{}field.remove();button.focus();
     }
     setStatus(ok?'Citation copied.':'Copy failed. Please select and copy the citation manually.');button.textContent=ok?'Copied! ✓':'Copy failed';button.classList.toggle('copied',ok);
     const timer=setTimeout(()=>{button.textContent='Copy';button.classList.remove('copied');timers.delete(timer)},1800);timers.add(timer);
    });entry.appendChild(button);
   });
  };
  const keydown=(e:KeyboardEvent)=>{
   const target=e.target as HTMLElement;
   const editing=target?.closest('input,textarea,select,[contenteditable]:not([contenteditable="false"]),[role="textbox"]');
   const search=document.querySelector<HTMLInputElement>('input[type="search"]');
   if(dialog.current?.open)return;
   if(document.querySelector('dialog[open]'))return;
   if(e.key==='Escape'&&target===search){window.dispatchEvent(new Event('clear-library-search'));return;}
   if(editing)return;
   if(e.key==='?'&&!e.ctrlKey&&!e.metaKey){e.preventDefault();dialog.current?.showModal();return;}
   const shortcut=(e.key==='/'&&!e.ctrlKey&&!e.metaKey&&!e.altKey)||((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k');
   if(shortcut&&search){e.preventDefault();search.focus();search.select();return;}
   if(e.ctrlKey||e.metaKey||e.altKey)return;
   const items=Array.from(document.querySelectorAll<HTMLElement>('.cs-row,.apa-entry,.dir-item')).filter(el=>el.getClientRects().length>0);
   if(!items.length)return;
   const active=items.findIndex(el=>el===document.activeElement||el.contains(document.activeElement)||el.classList.contains('focused'));
   if(['j','k','ArrowDown','ArrowUp'].includes(e.key)){
    if(target?.closest('button,a')&&!target.closest('.cs-row,.apa-entry,.dir-item'))return;
    e.preventDefault();const next=active<0?0:Math.max(0,Math.min(items.length-1,active+(['j','ArrowDown'].includes(e.key)?1:-1)));
    items.forEach(el=>el.classList.remove('focused'));items[next].classList.add('focused');items[next].tabIndex=-1;items[next].focus({preventScroll:true});items[next].scrollIntoView({block:'nearest'});
   }else if(e.key.toLowerCase()==='c'&&active>=0){
    const button=items[active].querySelector<HTMLButtonElement>('.cite-copy-btn');if(button)button.click();else{
     const cells=Array.from(items[active].querySelectorAll('td')).map(cell=>cell.textContent?.trim()).join(' | ');
     navigator.clipboard.writeText(cells||items[active].textContent||'').then(()=>setStatus('Row copied.')).catch(()=>setStatus('Copy failed. Please select the text and copy manually.'));
    }
   }
  };
  enhance();const observer=new MutationObserver(enhance);observer.observe(document.getElementById('main')||document.body,{childList:true,subtree:true});window.addEventListener('keydown',keydown);
  return()=>{observer.disconnect();window.removeEventListener('keydown',keydown);timers.forEach(clearTimeout);};
 },[path]);return <><span className="sr-only" role="status">{status}</span><dialog ref={dialog} className="cs-modal" aria-labelledby="shortcut-title" onClick={e=>{if(e.target===dialog.current)dialog.current.close()}}><h3 id="shortcut-title">Reference &amp; Table Shortcuts</h3>{[["Focus search","/ · ⌘K · Ctrl K"],["Next reference / row","J · ↓"],["Previous reference / row","K · ↑"],["Copy active citation / row","C"],["Close dialog / clear focused search","Esc"],["Open shortcuts","?"]].map(([label,key])=><div className="cs-shortcut-row" key={label}><span>{label}</span><kbd>{key}</kbd></div>)}<button className="neu-btn" style={{marginTop:20}} onClick={()=>dialog.current?.close()}>Got it (Esc)</button></dialog></>;
}
