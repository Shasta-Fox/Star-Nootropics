import { LearnQuickRef } from "@/components/LearnQuickRef";
import { QuickReference } from "@/components/QuickReference";
import { ReadingLibrary } from "@/components/ReadingLibrary";
export const metadata = { title: "Reference Library — Star Nootropics" };
export default function Library() {
  return <>
    <header className="intro libraryIntro"><span className="eyebrow">Reading / Academic collection</span><h1>Reference Library</h1><p>Empirical literature, books, monographs, and protocol documentation. Search by author, title, compound, topic, or year.</p><p><a href="/evidence-protocol">Evidence Protocol &amp; Review Methodology</a> · <a href="/papers">Search the paper catalog</a></p></header>
    <section className="star-nootropics-bibliography" aria-label="Reference collection"><ReadingLibrary/></section>
    <QuickReference/><LearnQuickRef/>
    <section className="panel"><h2>Compound research</h2><p><a href="/nootropics/racetams/piracetam">Piracetam</a> · <a href="/nootropics/racetams/oxiracetam">Oxiracetam</a> · <a href="/nootropics/racetams/aniracetam">Aniracetam</a> · <a href="/research/noopept">Noopept</a> · <a href="/nootropics/botanicals/bacopa-monnieri">Bacopa</a></p><p><a href="/oxiracetam-library">Oxiracetam literature archive</a> · <a href="/journal">Research Journal</a></p></section>
  </>;
}
